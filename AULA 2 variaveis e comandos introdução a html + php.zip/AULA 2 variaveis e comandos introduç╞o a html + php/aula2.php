<?php
    $nome = "Feliphe";
    $numero = 10;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variável e Operadores</title>
</head>
<body>
    <h1>
        <?php //echo $nome." ".$numero; 
            echo "$nome $numero";    
        ?>
    </h1>
    <br><br>
    <?php
        $numero++;
        echo "agora o número vale: <br> $numero";
        echo "<br>";       
        $numero+=2;//$numero = $numero + 2;
        echo "agora o número vale: <br> $numero <br>";
        var_dump($nome);
    ?>
    
</body>
</html>